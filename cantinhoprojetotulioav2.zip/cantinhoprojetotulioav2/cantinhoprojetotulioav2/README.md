# WEB-INF
 Av2-Topicos-Integradores
 Pergunta 1
10 pontos
A atividade Integradora 2, da segunda semana, consiste em desenvolver interfaces para a Web (Front-end), correspondentes a um sistema simples de cadastro de cães e suas respectivas raças para um canil hipotético.
Junto à web-aula 2 está um vídeo explicativo dos fluxos de informações a serem contemplados no seu código, que deverá utilizar exclusivamente HTML como linguagem base, CSS para os estilos Java Script para o comportamento dinâmico do seu front-end.
Basicamente, o sistema deverá conter duas páginas:
1) Página inicial, linkando para as duas páginas seguintes
2) Página de Cadastro e Listagem de Raças
3) Página de Cadastro e Listagem de Cães (escolhendo uma raça à qual o cão deverá pertencer).
Importante reforçar que você fará apenas o front-end (Html, CSS e JS puros)... não haverá requisições ou códigos server-side no seu projeto.
Como entregar o projeto:
O entregável desta atividade deve conter:
1) arquivos html, css e js em uma única pasta compactada com o formato zip, que deverá rodar no navegador Chrome atualizado.
2) Um vídeo rápido (capturando a tela e sua voz, onde você mostrará e explicará seu código e mostrará o front-end rodando com os dados fictícios controlados pelo JavaScript.
Saiba que estamos no Tópico Integrador 02 desta disciplina, nele você realizará a Atividade Integradora 2 e ela considerará os conhecimentos relacionados à disciplina de Desenvolvimento de Interfaces Web. O(s) arquivo(s) produzido(s) deverá(ão) ser submetido(s) na Avaliação Online 2, no AVA.
Observação: Se necessário, pesquise na internet ou nos livros da biblioteca virtual da instituição conteúdos complementares para a execução da atividade solicitada.

